import { createClient } from "@supabase/supabase-js";

// Environment Validation
const requiredEnv = ["SUPABASE_URL", "SUPABASE_SERVICE_ROLE_KEY", "API_SECRET"];
for (const env of requiredEnv) {
  if (!process.env[env]) {
    throw new Error(`CRITICAL ERROR: Environment variable ${env} is not set.`);
  }
}

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

export default async function handler(req, res) {
  // 1. Strict Method Handling
  if (req.method !== "GET") {
    return res.status(405).json({ success: false, error: "Method not allowed. Use GET." });
  }

  // 2. Security Check (Strict API_SECRET, no fallback)
  const { id, token } = req.query;
  const apiSecret = process.env.API_SECRET;

  if (token !== apiSecret) {
    console.warn(`Unauthorized accept attempt for booking ${id} with token ${token?.substring(0, 4)}...`);
    return res.status(401).json({ success: false, error: "Unauthorized" });
  }

  if (!id) {
    return res.status(400).json({ success: false, error: "Missing booking ID" });
  }

  try {
    // 3. Fetch booking to verify current state
    const { data: booking, error: fetchError } = await supabase
      .from("bookings")
      .select("*")
      .eq("id", id)
      .single();

    if (fetchError || !booking) {
      console.error(`Accept failed: Booking ${id} not found.`);
      return res.status(404).json({ success: false, error: "Booking not found", details: fetchError?.message });
    }

    if (booking.status === "accepted") {
      console.log(`Accept check: Booking ${id} was already accepted.`);
      return res.status(200).json({ success: true, message: "Ride already accepted", status: "accepted" });
    }

    // 4. Update with race condition protection
    const { data, error: updateError } = await supabase
      .from("bookings")
      .update({
        status: "accepted",
        accepted_at: new Date()
      })
      .eq("id", id)
      .eq("status", "assigned") // Mandatory protection: only assign if it's currently assigned
      .select();

    if (updateError) {
      throw updateError;
    }

    if (!data || data.length === 0) {
      console.warn(`Accept conflict for booking ${id}: status was not 'assigned'.`);
      return res.status(409).json({ success: false, error: "Conflict: Ride may have been re-assigned or already accepted by someone else" });
    }

    console.log(`Accept success: Booking ${id} is now confirmed.`);
    return res.status(200).json({ success: true, message: "Ride accepted ✅" });

  } catch (err) {
    console.error("ACCEPT HANDLER ERROR:", err);
    return res.status(500).json({ success: false, error: "Accept failed", details: err.message });
  }
}
