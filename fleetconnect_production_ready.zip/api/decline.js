import { createClient } from "@supabase/supabase-js";

// Environment Validation
const requiredEnv = ["SUPABASE_URL", "SUPABASE_SERVICE_ROLE_KEY", "API_SECRET"];
for (const env of requiredEnv) {
  if (!process.env[env]) {
    throw new Error(`CRITICAL ERROR: Environment variable ${env} is not set.`);
  }
}

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

export default async function handler(req, res) {
  // 1. Strict Method Handling
  if (req.method !== "GET") {
    return res.status(405).json({ success: false, error: "Method not allowed. Use GET." });
  }

  // 2. Security Check (Strict API_SECRET)
  const { id, token } = req.query;
  const apiSecret = process.env.API_SECRET;

  if (token !== apiSecret) {
    console.warn(`Unauthorized decline attempt for booking ${id}.`);
    return res.status(401).json({ success: false, error: "Unauthorized" });
  }

  if (!id) {
    return res.status(400).json({ success: false, error: "Missing booking ID" });
  }

  try {
    // 3. Reset booking to pool (Keep logic and consistency)
    const { error: resetError } = await supabase
      .from("bookings")
      .update({
        status: "pending",      // 🔥 Send back to pool
        driver_id: null,        // Clear driver assignment (integer)
        declined_at: new Date(),
      })
      .eq("id", id);

    if (resetError) {
      throw resetError;
    }

    console.log(`Decline success: Booking ${id} has been returned to the pool.`);

    // 4. Future Ready Placeholder
    // TODO: implement auto-reassign logic here
    // await fetch(baseUrl + "/api/auto-reassign", { ... });

    return res.status(200).json({ success: true, message: "Ride declined → returned to pool 🔁" });

  } catch (err) {
    console.error("DECLINE HANDLER ERROR:", err);
    return res.status(500).json({ success: false, error: "Decline failed", details: err.message });
  }
}
