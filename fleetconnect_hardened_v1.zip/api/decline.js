import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

export default async function handler(req, res) {
  // 1. Security Check
  const { id, token } = req.query;
  const apiSecret = process.env.API_SECRET || "default_secret";

  if (token !== apiSecret) {
    console.error(`Unauthorized decline attempt for booking ${id}`);
    return res.status(401).json({ error: "Unauthorized" });
  }

  if (!id) {
    return res.status(400).json({ error: "Missing booking ID" });
  }

  try {
    // 2. Reset booking to pool
    const { error } = await supabase
      .from("bookings")
      .update({
        status: "pending",      // 🔥 send back to pool
        driver_id: null,        // clear driver_id (integer)
        declined_at: new Date(),
      })
      .eq("id", id);

    if (error) {
      throw error;
    }

    console.log(`Ride declined and returned to pool: booking ${id}`);
    return res.status(200).json({ success: true, message: "Ride declined → returned to pool 🔁" });

  } catch (err) {
    console.error("DECLINE HANDLER ERROR:", err);
    return res.status(500).json({ error: "Decline failed", details: err.message });
  }
}
