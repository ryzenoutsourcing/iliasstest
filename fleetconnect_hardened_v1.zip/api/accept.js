import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

export default async function handler(req, res) {
  // 1. Security Check
  const { id, token } = req.query;
  const apiSecret = process.env.API_SECRET || "default_secret";

  if (token !== apiSecret) {
    console.error(`Unauthorized accept attempt for booking ${id}`);
    return res.status(401).json({ error: "Unauthorized" });
  }

  if (!id) {
    return res.status(400).json({ error: "Missing booking ID" });
  }

  try {
    // 2. Fetch booking to verify current status
    const { data: booking, error: fetchError } = await supabase
      .from("bookings")
      .select("*")
      .eq("id", id)
      .single();

    if (fetchError || !booking) {
      return res.status(404).json({ error: "Booking not found" });
    }

    if (booking.status === "accepted") {
      return res.status(200).json({ message: "Ride already accepted", status: "accepted" });
    }

    // 3. Update with race condition protection
    // Only update if status is still 'assigned'
    const { data, error: updateError } = await supabase
      .from("bookings")
      .update({
        status: "accepted",
        accepted_at: new Date()
      })
      .eq("id", id)
      .eq("status", "assigned")
      .select();

    if (updateError) {
      throw updateError;
    }

    if (!data || data.length === 0) {
      console.log(`Accept failed for booking ${id}: status was not 'assigned' (likely already handled)`);
      return res.status(409).json({ error: "Conflict: Ride may have been re-assigned or already accepted" });
    }

    console.log(`Ride accepted successfully: booking ${id}`);
    return res.status(200).json({ success: true, message: "Ride accepted ✅" });

  } catch (err) {
    console.error("ACCEPT HANDLER ERROR:", err);
    return res.status(500).json({ error: "Accept failed", details: err.message });
  }
}
