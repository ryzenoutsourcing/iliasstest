import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { bookingId, driverId } = req.body;

  if (!bookingId || !driverId) {
    return res.status(400).json({ error: "Missing bookingId or driverId" });
  }

  try {
    const baseUrl = process.env.BASE_URL || "https://fleetconnect-three.vercel.app";

    // 1. Assign booking using driver_id (integer)
    const { data: booking, error: assignError } = await supabase
      .from("bookings")
      .update({
        driver_id: driverId,
        assigned_at: new Date(),
        status: "assigned",
      })
      .eq("id", bookingId)
      .select()
      .single();

    if (assignError) {
      console.error("SUPABASE ASSIGN ERROR:", assignError);
      return res.status(500).json({ error: "Database assignment failed", details: assignError.message });
    }

    console.log(`Assignment success: Booking ${bookingId} assigned to driver ${driverId}`);

    // 2. Send email via internal API (Wrapped in try/catch to ensure assignment succeeds even if email fails)
    try {
      const emailRes = await fetch(`${baseUrl}/api/send-driver-email`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          driverId: driverId,
          booking: {
            id: booking.id,
            pickup: booking.pickup,
            dropoff: booking.destination,
            name: booking.name,
            phone: booking.phone,
            date: booking.datetime,
            time: booking.time,
            vehicle: booking.vehicle,
            passengers: booking.passengers,
            extras: booking.extras,
            price: booking.amount,
            template: booking.template,
            flight: booking.flight_number
          }
        }),
      });

      if (!emailRes.ok) {
        console.error(`Email failed with status ${emailRes.status}`);
      } else {
        console.log(`Email successfully sent for booking ${bookingId}`);
      }
    } catch (emailErr) {
      console.error("CRITICAL EMAIL CALL ERROR:", emailErr.message);
      // Assignment still succeeded, so we don't return an error here.
    }

    return res.status(200).json({ success: true, bookingId: booking.id });

  } catch (err) {
    console.error("UNEXPECTED ASSIGN HANDLER ERROR:", err);
    return res.status(500).json({ error: "Internal server error", details: err.message });
  }
}
