import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

export default async function handler(req, res) {
  const { bookingId, driverId } = req.body;

  if (!bookingId || !driverId) {
    return res.status(400).json({ error: "Missing bookingId or driverId" });
  }

  try {
    // 1. Assign booking using driver_id (integer)
    const { data: booking, error } = await supabase
      .from("bookings")
      .update({
        driver_id: driverId,
        assigned_at: new Date(),
        status: "assigned",
      })
      .eq("id", bookingId)
      .select()
      .single();

    if (error) throw error;

    // 2. Send email via internal API (Email API will fetch driver details)
    await fetch(`${process.env.BASE_URL}/api/send-driver-email`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        driverId: driverId,
        booking: {
          id: booking.id,
          pickup: booking.pickup,
          dropoff: booking.destination,
          name: booking.name,
          phone: booking.phone,
          date: booking.datetime,
          time: booking.time,
          vehicle: booking.vehicle,
          passengers: booking.passengers,
          extras: booking.extras,
          price: booking.amount,
          template: booking.template,
          flight: booking.flight_number
        }
      }),
    });

    return res.json({ success: true });

  } catch (err) {
    console.error("ASSIGN ERROR:", err);
    return res.status(500).json({ error: err.message });
  }
}
