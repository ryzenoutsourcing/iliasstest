import { createClient } from "@supabase/supabase-js";

// Environment Validation
const requiredEnv = ["SUPABASE_URL", "SUPABASE_SERVICE_ROLE_KEY", "API_SECRET"];
for (const env of requiredEnv) {
  if (!process.env[env]) {
    throw new Error(`CRITICAL ERROR: Environment variable ${env} is not set.`);
  }
}

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

export default async function handler(req, res) {
  if (req.method !== "GET") {
    return res.status(405).json({ success: false, error: "Method not allowed. Use GET." });
  }

  const { id, token } = req.query;

  if (!id || !token) {
    return res.status(400).json({ success: false, error: "Missing booking ID or token" });
  }

  try {
    // 1. Validate token from database
    const { data: booking, error: fetchError } = await supabase
      .from("bookings")
      .select("*")
      .eq("id", id)
      .single();

    if (fetchError || !booking) {
      return res.status(404).json({ success: false, error: "Booking not found" });
    }

    if (!booking.action_token || booking.action_token !== token) {
      console.warn(`Decline blocked: Invalid or expired token for booking ${id}.`);
      return res.status(401).json({ success: false, error: "Unauthorized or link expired" });
    }

    // 2. Reset booking to pool and invalidate token
    const { error: resetError } = await supabase
      .from("bookings")
      .update({
        status: "pending",      // returned to pool
        driver_id: null,        // clear driver
        action_token: null,     // invalidate token
        declined_at: new Date(),
      })
      .eq("id", id)
      .eq("action_token", token); // safety check

    if (resetError) {
      throw resetError;
    }

    console.log(`Decline success: Booking ${id} returned to pool. Token invalidated.`);

    // 3. Placeholder for future auto-reassign logic
    // TODO: implement auto-reassign hook

    return res.status(200).json({ success: true, message: "Ride declined → returned to pool 🔁" });

  } catch (err) {
    console.error("DECLINE HANDLER ERROR:", err);
    return res.status(500).json({ success: false, error: "Decline failed", details: err.message });
  }
}
