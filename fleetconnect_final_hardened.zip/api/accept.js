import { createClient } from "@supabase/supabase-js";

// Environment Validation
const requiredEnv = ["SUPABASE_URL", "SUPABASE_SERVICE_ROLE_KEY", "API_SECRET"];
for (const env of requiredEnv) {
  if (!process.env[env]) {
    throw new Error(`CRITICAL ERROR: Environment variable ${env} is not set.`);
  }
}

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

export default async function handler(req, res) {
  if (req.method !== "GET") {
    return res.status(405).json({ success: false, error: "Method not allowed. Use GET." });
  }

  const { id, token } = req.query;

  if (!id || !token) {
    return res.status(400).json({ success: false, error: "Missing booking ID or token" });
  }

  try {
    // 1. Fetch booking and validate token
    const { data: booking, error: fetchError } = await supabase
      .from("bookings")
      .select("*")
      .eq("id", id)
      .single();

    if (fetchError || !booking) {
      return res.status(404).json({ success: false, error: "Booking not found" });
    }

    // Security Check: token must match action_token in DB
    if (!booking.action_token || booking.action_token !== token) {
      console.warn(`Unauthorized or expired token attempt for booking ${id}.`);
      return res.status(401).json({ success: false, error: "Unauthorized or link expired" });
    }

    if (booking.status === "accepted") {
      return res.status(200).json({ success: true, message: "Ride already accepted" });
    }

    // 2. Accept booking with race-condition protection and token invalidation
    const { data, error: updateError } = await supabase
      .from("bookings")
      .update({
        status: "accepted",
        accepted_at: new Date(),
        action_token: null // Invalidate token after success
      })
      .eq("id", id)
      .eq("status", "assigned")
      .eq("action_token", token) // Extra safety check
      .select();

    if (updateError) {
      throw updateError;
    }

    if (!data || data.length === 0) {
      return res.status(409).json({ success: false, error: "Conflict: Ride already handled or re-assigned" });
    }

    console.log(`Accept success: Booking ${id} is now confirmed. Token invalidated.`);
    return res.status(200).json({ success: true, message: "Ride accepted ✅" });

  } catch (err) {
    console.error("ACCEPT HANDLER ERROR:", err);
    return res.status(500).json({ success: false, error: "Accept failed", details: err.message });
  }
}
