import { createClient } from "@supabase/supabase-js";
import crypto from "crypto";

// Environment Validation
const requiredEnv = ["SUPABASE_URL", "SUPABASE_SERVICE_ROLE_KEY", "API_SECRET"];
for (const env of requiredEnv) {
  if (!process.env[env]) {
    throw new Error(`CRITICAL ERROR: Environment variable ${env} is not set.`);
  }
}

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ success: false, error: "Method not allowed. Use POST." });
  }

  const { bookingId, driverId } = req.body;

  if (!bookingId || !driverId) {
    return res.status(400).json({ success: false, error: "Missing bookingId or driverId" });
  }

  try {
    const baseUrl = process.env.BASE_URL || "https://fleetconnect-three.vercel.app";

    // 1. Validate Driver
    const { data: driver, error: driverError } = await supabase
      .from("chauffeurs")
      .select("*")
      .eq("id", driverId)
      .single();

    if (driverError || !driver) {
      console.warn(`Assignment blocked: Driver ${driverId} not found.`);
      return res.status(404).json({ success: false, error: "Driver not found" });
    }

    // 2. Generate secure one-time token
    const actionToken = crypto.randomBytes(32).toString("hex");

    // 3. Assign booking with token protection
    const { data: booking, error: assignError } = await supabase
      .from("bookings")
      .update({
        driver_id: driverId,
        assigned_at: new Date(),
        status: "assigned",
        action_token: actionToken
      })
      .eq("id", bookingId)
      .eq("status", "pending")
      .select()
      .single();

    if (assignError) {
      console.error("SUPABASE ASSIGN ERROR:", assignError);
      return res.status(500).json({ success: false, error: "Database assignment failed", details: assignError.message });
    }

    if (!booking) {
      return res.status(409).json({ success: false, error: "Conflict: Booking is no longer pending" });
    }

    console.log(`Assignment success: Booking ${bookingId} assigned to driver ${driverId} (Token generated)`);

    // 4. Send email (passing the actionToken)
    try {
      const emailRes = await fetch(`${baseUrl}/api/send-driver-email`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          driverId: driverId,
          actionToken: actionToken,
          booking: {
            id: booking.id,
            pickup: booking.pickup,
            dropoff: booking.destination,
            name: booking.name,
            phone: booking.phone,
            date: booking.datetime,
            time: booking.time,
            vehicle: booking.vehicle,
            passengers: booking.passengers,
            extras: booking.extras,
            price: booking.amount,
            template: booking.template,
            flight: booking.flight_number
          }
        }),
      });

      if (!emailRes.ok) {
        console.error(`Email dispatch failed with status ${emailRes.status}`);
      }
    } catch (emailErr) {
      console.error("EMAIL CALL ERROR:", emailErr.message);
    }

    return res.status(200).json({ success: true, bookingId: booking.id });

  } catch (err) {
    console.error("ASSIGN HANDLER ERROR:", err);
    return res.status(500).json({ success: false, error: "Internal server error", details: err.message });
  }
}
